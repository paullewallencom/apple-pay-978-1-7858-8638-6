//
//  ProductCard_ImageCell.m
//  MerchantApp
//
//  Created by Ernest Bruce on 2015-09-11.
//  Copyright (c) 2016 Ernest Bruce.
//

#import "ProductCard_ImageCell.h"

@implementation ProductCard_ImageCell

@end
