//
//  ProductCard_BuyCellContent.m
//  MerchantApp
//
//  Created by Ernest Bruce on 2015-09-11.
//  Copyright (c) 2016 Ernest Bruce.
//

#import "ProductCard_BuyCellContent.h"

@implementation ProductCard_BuyCellContent
@end
