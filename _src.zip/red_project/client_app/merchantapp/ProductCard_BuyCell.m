//
//  ProductCard_BuyCell.m
//  MerchantApp
//
//  Created by Ernest Bruce on 2015-09-11.
//  Copyright (c) 2016 Ernest Bruce.
//

#import "ProductCard_BuyCell.h"

@implementation ProductCard_BuyCell
@end
