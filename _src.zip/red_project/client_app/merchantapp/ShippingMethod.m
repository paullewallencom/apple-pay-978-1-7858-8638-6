//
//  ShippingMethod.m
//  MerchantApp
//
//  Created by Ernest Bruce on 2015-09-12.
//  Copyright (c) 2016 Ernest Bruce.
//

#import "ShippingMethod.h"

@implementation ShippingMethod
@end
