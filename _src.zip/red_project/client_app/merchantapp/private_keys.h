//
//  private_keys.h
//  MerchantApp
//
//  Created by Ernest Bruce on 2015-09-11.
//  Copyright (c) 2016 Ernest Bruce.
//

#ifndef private_keys_h
#define private_keys_h

// Stripe publishable key
NSString* const StripePublishableKey= @"<my_key>";

// Apple Pay merchant identifier
static NSString* ApplePay_merchant_identifier= @"<my_merchant_id>";


#endif /* private_Keys_h */
