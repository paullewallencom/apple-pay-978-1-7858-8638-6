//
//  ProductCard_ImageCell.h
//  MerchantApp
//
//  Created by Ernest Bruce on 2015-09-11.
//  Copyright (c) 2016 Ernest Bruce.
//

#import <UIKit/UIKit.h>

@interface ProductCard_ImageCell : UITableViewCell
@property(nonatomic,weak) IBOutlet UIImageView *image_view;
@end
