//
//  ProductCard_DescriptionCell.m
//  MerchantApp
//
//  Created by Ernest Bruce on 2015-09-10.
//  Copyright (c) 2016 Ernest Bruce.
//

#import "ProductCard_DescriptionCell.h"

@implementation ProductCard_DescriptionCell
@synthesize description_label= _description_label;
@end
