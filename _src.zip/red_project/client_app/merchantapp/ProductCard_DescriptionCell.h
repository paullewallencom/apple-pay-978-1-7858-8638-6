//
//  ProductCard_DescriptionCell.h
//  MerchantApp
//
//  Created by Ernest Bruce on 2015-09-10.
//  Copyright (c) 2016 Ernest Bruce.
//

#import <UIKit/UIKit.h>

@interface ProductCard_DescriptionCell : UITableViewCell
@property(nonatomic,weak) IBOutlet UILabel *description_label;
@end
